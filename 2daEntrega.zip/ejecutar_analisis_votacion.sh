#!/bin/bash

python3.6 script_filter_votantes.py
python3.6 script_analisis_votacion.py
